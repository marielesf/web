<!DOCTYPE html>
<html lang="pt-br">
  <head>
	<title>Título da página</title>
	<meta charset="utf-8">
  </head>
  <body>
	<form method="post" action="valida.php">
	  <label>Usuário</label>
	  <input type="text" name="usuario" maxlength="50" />
	  
	  <label>Senha</label>
	  <input type="password" name="senha" maxlength="50" />
	  
	  <input type="submit" value="Entrar" />
	</form>
  </body>
</html>