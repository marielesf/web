<?php
session_start();
if(isset($_POST['login'])){
	$login = $_POST['login'];

	if(!isset($_SESSION['login'])){
	session_destroy();
    unset ($_SESSION['login']);
	header('location:login2.html');
	}else{
		header('location:index.php');;
	}
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $usuario = $_POST['usuario'];
  $senha = md5($_POST['senha']);
  $entrar = $_POST['entrar'];
  
  $connect = mysqli_connect("localhost", "root", "", "test") or die('Erro ao conectar ao banco de dados');
    if (isset($entrar)) {
             
		$query_select = "SELECT * FROM usuarios WHERE login = '$usuario' AND senha = '$senha'";
		$verifica = mysqli_query($connect, $query_select); 
      
        if(mysqli_num_rows($verifica)<=0){
          echo"<script language='javascript' type='text/javascript'>alert('Login e/ou senha incorretos');
		  window.location.href='login2.html';</script>";
          die();
        }else{
          setcookie("login",$login);
          header("Location:index.php");
        }
    }
}
  
?>
