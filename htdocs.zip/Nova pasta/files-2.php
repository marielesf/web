
<?php

require('contador.php');

?>

