<?php
if(isset($_COOKIE['contador'])) 
{
 $c = $_COOKIE['contador'];
 $c++;
 echo "Visita de número $c";
 setcookie('contador',$c,time()+60*60*365);
}
else //primeira visita
{
 echo '1ª visita';
 setcookie('contador',1,time()+60*60*24*365);
}
if(isset($_GET['excluir'])){
    setcookie('contador', "", time() - 3600);
	header('location: contadorUser_session.php');
}
?>
<br>
<a href ="?excluir">Zerar Contador </a>