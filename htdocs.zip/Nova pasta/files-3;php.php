<?php

$texto = file_get_contents('texto.txt');

$texto = str_replace('-','',$texto);
$texto = str_replace('!','',$texto);
$texto = str_replace('?','',$texto);
$texto = str_replace(',','',$texto);
$texto = str_replace('.','',$texto);
$texto = str_replace("\n",'',$texto);
$texto = str_replace("\r",'',$texto); //windows
$texto = str_replace(':','',$texto);
$texto = str_replace("  "," ",$texto);
$texto = str_replace("  "," ",$texto);

$texto = mb_strtolower($texto);

$array = explode(' ',$texto);

//print_r($array);

$arrayresultante = array_count_values($array);
arsort($arrayresultante);

?>

<table>
	<tr><td><b>Palavra</b></td><td><b>Total</b></td></tr>
		<?php foreach ($arrayresultante as $palavra=>$total) {
			if ($total != 1) {
			echo "<tr><td>$palavra</td><td>$total</td></tr>";
		}
		}?>
</table>