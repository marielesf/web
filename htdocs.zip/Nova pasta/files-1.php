
<?php


$cont = file_get_contents('contador.php');
if ($cont == "") {
	$cont = 1;
} else { 
	$cont += 1;
}

if (isset($_GET['excluir'])) {
	$cont = 0;
	header ('location: files-1.php');
}

file_put_contents('contador.php', $cont);


?>

<a href = "?excluir=1"><?=$cont?></a>

