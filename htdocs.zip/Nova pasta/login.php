<?php 
session_start();
if(isset($_POST['login']) and isset($_POST['senha'])){
	$login = $_POST['login'];
	$senha = $_POST['senha'];

	if($login == 'user' and $senha == '123'){
		$_SESSION['login'] = $login;
		$_SESSION['senha'] = $senha;
		echo "Bem vindo ".$login;
	}else{
		session_destroy();
		unset ($_SESSION['login']);
		unset ($_SESSION['senha']);
		header('location:form_session.php');
	}
}
else{
	if(!isset($_SESSION['login']) and !isset($_SESSION['senha'])){
	session_destroy();
    unset ($_SESSION['login']);
    unset ($_SESSION['senha']);
	header('location:form_session.php');
	}else{
		    echo "Bem vindo de volta!";
	}
}
 
?>