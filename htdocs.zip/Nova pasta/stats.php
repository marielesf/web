<?php


calcularExpressao ();
$estados = array('AC' => 'Acre', 'AL'=>'Alagoas', 'AP'=>'Amapá', 'AM'=>'Amazonas',   'BA'  =>'Bahia',  'CE'  =>'Ceará',   'DF'  =>'Distrito Federal',   'ES'  =>'Espírito Santo',   'GO'  =>'Goiás',   'MA'  =>'Maranhão', 	  'MT'  =>'Mato Grosso', 	  'MS'  =>'Mato Grosso do Sul', 	  'MG'  =>'Minas Gerais',   'PA'  =>'Pará',   'PB'  =>'Paraíba',   'PR'  =>'Paraná',  'PE'  =>'Pernambuco',   'PI'  =>'Piauí',   'RJ'  =>'Rio de Janeiro',   'RN'  =>'Rio Grande do Norte',  'RS'  =>'Rio Grande do Sul',   'RO'  =>'Rondônia',   'RR'  =>'Roraima',   'SC'  =>'Santa Catarina',   'SP'  =>'São Paulo',   'SE'  =>'Sergipe',   'TO'  =>'Tocantins');
mostrarArrayHTML($estados);


function soma($a, $b) { 
 return $a + $b; 
}

function subtracao($a, $b) { 
 return (soma($a, -$b)); 
}

function multiplicacao ($a, $b) { 
 return $a * $b; 
}

function divisao ($a, $b) { 
 return (multiplicacao($a, $b)/$b)/$b; 
} 

function calcularExpressao () { 
 $result = divisao (4,5); //0.8
 echo $result . " ";
 $result = multiplicacao(3, $result); //2.4
 echo $result . " ";
 $valorPositivo = soma(1, 2);
 echo $valorPositivo . " ";
 $result = subtracao($valorPositivo, $result);
 echo "\n Resultado = " . $result . " ";
} 


function mostrarArrayHTML ($estados) { 
?>
	<ul style="list-style-type:none">
	<?php for ($i=0; $i<=count($estados); $i++) {?>
		<li>
			<?php echo $estados[$i];?> 
		</li>
	</ul>
	<?php 
	}
}
?>