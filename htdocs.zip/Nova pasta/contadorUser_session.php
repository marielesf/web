<?php
session_start();
if (!isset($_SESSION['count'])) {
  $_SESSION['count'] = 0;
} else {
  $_SESSION['count']++;
}
if(isset($_GET['excluir'])){
    unset($_SESSION['count']);
	session_destroy(); 
	header('location: contadorUser_session.php');
}
echo "Numero de acessos: ". $_SESSION['count'];
?>
<br>
<a href ="?excluir">Zerar Contador </a>