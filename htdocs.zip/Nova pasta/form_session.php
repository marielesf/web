<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Cookies e Sessões</title>
</head>
<body>
<?php 
session_start();
if((isset($_SESSION['login'])) and (isset($_SESSION['senha'])))
{
    echo "Bem vindo de volta!";
} else { 
?>
	<form action="login.php" method="POST">
	
	Username: <input type="text" name="login"><br>
	<br>
	Password: <input type="password" name="senha">

		<div class="button">
			<button type="submit">Enviar</button>
		</div>
	</form>
<?php 
} 
?>
</body>
</html>

