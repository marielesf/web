<pre>
<?php
include('Ex2_Orientacao_a_objetos.php');

$classe = new Funcionario();

print_r($classe);
?>
</pre>