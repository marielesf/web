<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <title>Exercício 2</title>
    <meta charset="utf-8">
  </head>
  <body>
	<?php
		require ("contador.php");
	?> 
  </body>
</html>